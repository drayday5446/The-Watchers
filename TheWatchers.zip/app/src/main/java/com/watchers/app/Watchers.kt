package com.watchers.app

import android.content.SharedPreferences
import android.graphics.Typeface
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalTime
import kotlin.math.cos
import kotlin.math.sin

// ---------- Palettes ----------
class Pal(
    val bg: Color, val text: Color, val muted: Color, val acc: Color, val accOn: Color,
    val line: Color, val glassTop: Color, val glassBot: Color, val glass2: Color, val scrim: Color,
    val chipOn: Color, val chipOnText: Color, val blob1: Color, val blob2: Color,
    val bezel: Color, val dial: Color, val hand: Color, val dial2: Color, val dial3: Color,
    val shadow: Color
)

val DarkPal = Pal(
    bg = Color(0xFF07080A), text = Color(0xFFF2EEE6), muted = Color(0xFFA9A59C),
    acc = Color(0xFFC8A96A), accOn = Color(0xFF14110A), line = Color(0x21FFFFFF),
    glassTop = Color(0x21FFFFFF), glassBot = Color(0x08FFFFFF), glass2 = Color(0xD91E1F24),
    scrim = Color(0x9E040507), chipOn = Color(0xFFF2EEE6), chipOnText = Color(0xFF0B0C0F),
    blob1 = Color(0xFF2E3B66), blob2 = Color(0xFF5A3D22), bezel = Color(0xFF2A2C33),
    dial = Color(0xFF101218), hand = Color(0xFFF2EEE6), dial2 = Color(0xFF0F2A3A),
    dial3 = Color(0xFF1A1C22), shadow = Color(0xFF000000)
)

val LightPal = Pal(
    bg = Color(0xFFF1EDE6), text = Color(0xFF1A1A1A), muted = Color(0xFF5E5B55),
    acc = Color(0xFF8A6A2F), accOn = Color(0xFFFFFFFF), line = Color(0x17000000),
    glassTop = Color(0xEBFFFFFF), glassBot = Color(0x80FFFFFF), glass2 = Color(0xE6FFFFFF),
    scrim = Color(0x99F1EDE6), chipOn = Color(0xFF1A1A1A), chipOnText = Color(0xFFF4F1EC),
    blob1 = Color(0xFFBFD3E6), blob2 = Color(0xFFEBCFA6), bezel = Color(0xFFD9D5CC),
    dial = Color(0xFFFAF8F4), hand = Color(0xFF1A1A1A), dial2 = Color(0xFFDCE8EE),
    dial3 = Color(0xFFF0ECE4), shadow = Color(0xFF46371E)
)

// ---------- Data ----------
enum class Screen { Catalog, Trending, Feed, Watches, Search }

data class Watch(val name: String, val sub: String, val cat: String, val trend: Boolean, val style: Int)

val ALL = listOf(
    Watch("Meridian Dress 38", "Dress · 38 mm", "Dress", true, 0),
    Watch("Tidewater Diver 41", "Dive · 41 mm", "Dive", true, 1),
    Watch("Alder Chrono 40", "Sport · 40 mm", "Sport", false, 2),
    Watch("Ridgeline Field 38", "Field · 38 mm", "Field", true, 0),
    Watch("Nocturne Dress 36", "Dress · 36 mm", "Dress", false, 2),
    Watch("Harbor Diver 44", "Dive · 44 mm", "Dive", false, 1),
    Watch("Quarry Field 40", "Field · 40 mm", "Field", false, 2)
)

fun dialOf(p: Pal, s: Int): Color = when (s) { 0 -> p.dial; 1 -> p.dial2; else -> p.dial3 }

class Saved(private val prefs: SharedPreferences, private val key: String) {
    val items = mutableStateListOf<String>().also { it.addAll(prefs.getStringSet(key, emptySet()) ?: emptySet()) }
    fun has(n: String): Boolean = n in items
    fun toggle(n: String) {
        if (n in items) items.remove(n) else items.add(n)
        prefs.edit().putStringSet(key, items.toSet()).apply()
    }
}

// ---------- Helpers ----------
fun Modifier.bubble(p: Pal, shape: Shape): Modifier = this
    .shadow(18.dp, shape, ambientColor = p.shadow, spotColor = p.shadow)
    .background(Brush.verticalGradient(listOf(p.glassTop, p.glassBot)), shape)
    .border(1.dp, Brush.verticalGradient(listOf(p.text.copy(alpha = 0.35f), p.line)), shape)

fun polar(c: Offset, rad: Float, deg: Double): Offset {
    val a = Math.toRadians(deg - 90.0)
    return Offset(c.x + (cos(a) * rad).toFloat(), c.y + (sin(a) * rad).toFloat())
}

@Composable
fun rememberNow(): LocalTime {
    var now by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalTime.now()
            delay(1000)
        }
    }
    return now
}

// ---------- Watch face ----------
@Composable
fun WatchFace(
    size: Dp, p: Pal, dial: Color, h: Int, m: Int, s: Int = 0,
    showSec: Boolean = false, digital: Boolean = false, hands: Boolean = true
) {
    Box(
        Modifier
            .size(size)
            .shadow(10.dp, CircleShape, ambientColor = p.shadow, spotColor = p.shadow)
            .background(p.bezel, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.size(size * 0.84f).background(dial, CircleShape), contentAlignment = Alignment.Center) {
            if (digital) {
                Text(
                    String.format("%02d:%02d", h, m), color = p.acc,
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                    fontSize = (size.value * 0.22f).sp
                )
            } else {
                Canvas(Modifier.fillMaxSize()) {
                    val c = center
                    val r = this.size.minDimension / 2f
                    for (i in 0 until 12) {
                        val len = if (i % 3 == 0) r * 0.16f else r * 0.08f
                        drawLine(
                            p.hand.copy(alpha = 0.6f),
                            polar(c, r * 0.92f, i * 30.0),
                            polar(c, r * 0.92f - len, i * 30.0),
                            strokeWidth = r * 0.03f, cap = StrokeCap.Round
                        )
                    }
                    if (hands) {
                        val hourDeg = ((h % 12) + m / 60.0) * 30.0
                        val minDeg = (m + s / 60.0) * 6.0
                        drawLine(p.hand, c, polar(c, r * 0.5f, hourDeg), strokeWidth = r * 0.07f, cap = StrokeCap.Round)
                        drawLine(p.acc, c, polar(c, r * 0.72f, minDeg), strokeWidth = r * 0.045f, cap = StrokeCap.Round)
                        if (showSec) {
                            drawLine(p.acc, c, polar(c, r * 0.8f, s * 6.0), strokeWidth = r * 0.02f, cap = StrokeCap.Round)
                        }
                        drawCircle(p.acc, r * 0.07f, c)
                    }
                }
            }
        }
    }
}

// ---------- Cards ----------
@Composable
fun FeaturedCard(p: Pal, w: Watch, box: Saved) {
    Column(
        Modifier.fillMaxWidth().bubble(p, RoundedCornerShape(32.dp)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        WatchFace(130.dp, p, dialOf(p, w.style), 10, 10, 35)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text(if (w.trend) "TRENDING NOW" else "FEATURED", color = p.acc, fontSize = 12.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Medium)
                Text(w.name, color = p.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(w.sub, color = p.muted, fontSize = 13.sp)
            }
            Box(
                Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).background(p.acc)
                    .clickable { box.toggle(w.name) }.padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(if (box.has(w.name)) "In box" else "Add", color = p.accOn, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun SmallCard(p: Pal, w: Watch, wish: Saved, box: Saved, modifier: Modifier = Modifier) {
    Column(
        modifier.bubble(p, RoundedCornerShape(24.dp)).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        WatchFace(84.dp, p, dialOf(p, w.style), 10, 10, 35)
        Column(Modifier.fillMaxWidth()) {
            Text(w.name, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(w.sub, color = p.muted, fontSize = 12.sp, maxLines = 1)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            IconButton(onClick = { wish.toggle(w.name) }) {
                Icon(Icons.Default.Favorite, "Wishlist", tint = if (wish.has(w.name)) p.acc else p.muted)
            }
            IconButton(onClick = { box.toggle(w.name) }) {
                Icon(
                    if (box.has(w.name)) Icons.Default.Check else Icons.Default.Add, "Watch box",
                    tint = if (box.has(w.name)) p.acc else p.muted
                )
            }
        }
    }
}

@Composable
fun Grid(p: Pal, list: List<Watch>, wish: Saved, box: Saved) {
    list.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            row.forEach { SmallCard(p, it, wish, box, Modifier.weight(1f)) }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun Section(p: Pal, list: List<Watch>, wish: Saved, box: Saved, featuredFirst: Boolean) {
    if (list.isEmpty()) {
        Text("Nothing here yet.", color = p.muted, fontSize = 15.sp)
        return
    }
    if (featuredFirst) {
        FeaturedCard(p, list.first(), box)
        Grid(p, list.drop(1), wish, box)
    } else {
        Grid(p, list, wish, box)
    }
}

// ---------- Logo ----------
@Composable
fun Logo(p: Pal, digital: Boolean, onClick: () -> Unit) {
    val field = remember { FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD)) }
    Text(
        "THE WATCHERS",
        color = if (digital) p.acc else p.text,
        fontFamily = if (digital) FontFamily.Monospace else field,
        fontWeight = FontWeight.Bold,
        fontSize = if (digital) 22.sp else 30.sp,
        letterSpacing = if (digital) 2.sp else 4.sp,
        modifier = Modifier.clickable { onClick() }.padding(vertical = 4.dp)
    )
}

@Composable
fun Frame(p: Pal, logoDigital: Boolean, onLogo: () -> Unit, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding()
            .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 200.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Logo(p, logoDigital, onLogo)
        content()
    }
}

// ---------- Bottom bar ----------
@Composable
fun Chip(p: Pal, text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(44.dp).clip(CircleShape)
            .background(if (selected) p.chipOn else p.glass2.copy(alpha = 0.5f))
            .border(1.dp, p.line, CircleShape)
            .clickable { onClick() }.padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) p.chipOnText else p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WatchButton(p: Pal, now: LocalTime, digital: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    Box(Modifier.size(68.dp).combinedClickable(onClick = onClick, onLongClick = onLong)) {
        WatchFace(68.dp, p, p.dial, now.hour, now.minute, now.second, showSec = true, digital = digital)
        Box(
            Modifier.align(Alignment.CenterEnd).offset(x = 4.dp).size(width = 7.dp, height = 12.dp)
                .background(p.acc, RoundedCornerShape(3.dp))
        )
    }
}

@Composable
fun BoxScope.BottomBar(
    p: Pal, screen: Screen, cat: String, onCat: (String) -> Unit,
    query: String, onQuery: (String) -> Unit, now: LocalTime, digital: Boolean,
    onOpen: () -> Unit, onToggleClock: () -> Unit
) {
    Column(
        Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().imePadding()
            .padding(start = 20.dp, end = 20.dp, bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (screen == Screen.Catalog) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Dress", "Sport", "Dive", "Field").forEach { Chip(p, it, cat == it) { onCat(it) } }
            }
        }
        if (screen == Screen.Search) {
            BasicTextField(
                value = query, onValueChange = onQuery, singleLine = true,
                textStyle = TextStyle(color = p.text, fontSize = 16.sp),
                cursorBrush = SolidColor(p.acc),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Box(
                        Modifier.fillMaxWidth().height(56.dp).bubble(p, CircleShape).padding(horizontal = 22.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (query.isEmpty()) Text("Search watches", color = p.muted, fontSize = 16.sp)
                        inner()
                    }
                }
            )
        }
        WatchButton(p, now, digital, onOpen, onToggleClock)
    }
}

// ---------- Radial menu ----------
@Composable
fun BoxScope.MenuBtn(
    p: Pal, label: String, icon: ImageVector, active: Boolean, dx: Dp, dy: Dp, onClick: () -> Unit
) {
    Box(
        Modifier.align(Alignment.Center).offset(dx, dy).size(68.dp)
            .shadow(8.dp, CircleShape, ambientColor = p.shadow, spotColor = p.shadow)
            .clip(CircleShape)
            .background(if (active) p.chipOn else p.glass2)
            .border(1.dp, p.line, CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, label, tint = if (active) p.chipOnText else p.text, modifier = Modifier.size(22.dp))
            Text(label, color = if (active) p.chipOnText else p.text, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun RadialMenu(p: Pal, now: LocalTime, current: Screen, onPick: (Screen) -> Unit, onClose: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(p.scrim)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
    ) {
        Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 134.dp).size(300.dp)) {
            Box(
                Modifier.align(Alignment.Center).size(240.dp)
                    .shadow(24.dp, CircleShape, ambientColor = p.shadow, spotColor = p.shadow)
                    .background(p.bezel, CircleShape)
            )
            Box(Modifier.align(Alignment.Center).size(216.dp).background(p.dial, CircleShape)) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = center
                    val r = this.size.minDimension / 2f
                    for (i in 0 until 12) {
                        val len = if (i % 3 == 0) r * 0.1f else r * 0.05f
                        drawLine(
                            p.hand.copy(alpha = 0.5f), polar(c, r * 0.95f, i * 30.0), polar(c, r * 0.95f - len, i * 30.0),
                            strokeWidth = r * 0.02f, cap = StrokeCap.Round
                        )
                    }
                }
                Text(
                    String.format("%02d:%02d", now.hour, now.minute), color = p.acc,
                    fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 34.dp)
                )
            }
            Box(
                Modifier.align(Alignment.CenterEnd).padding(end = 18.dp).size(width = 12.dp, height = 30.dp)
                    .background(p.acc, RoundedCornerShape(4.dp))
            )
            MenuBtn(p, "Catalog", Icons.Default.Home, current == Screen.Catalog, (-85).dp, (-85).dp) { onPick(Screen.Catalog) }
            MenuBtn(p, "Trending", Icons.Default.Star, current == Screen.Trending, 85.dp, (-85).dp) { onPick(Screen.Trending) }
            MenuBtn(p, "Feed", Icons.Default.Person, current == Screen.Feed, (-85).dp, 85.dp) { onPick(Screen.Feed) }
            MenuBtn(p, "Watches", Icons.Default.Favorite, current == Screen.Watches, 85.dp, 85.dp) { onPick(Screen.Watches) }
            Box(
                Modifier.align(Alignment.Center).size(72.dp).clip(CircleShape).background(p.acc)
                    .clickable { onPick(Screen.Search) },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Search, "Search", tint = p.accOn, modifier = Modifier.size(22.dp))
                    Text("Search", color = p.accOn, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Box(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp).size(68.dp)
                .clip(CircleShape).background(p.glass2).border(1.dp, p.line, CircleShape)
                .clickable { onClose() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Close, "Close menu", tint = p.text)
        }
    }
}

// ---------- App ----------
@Composable
fun Blob(color: Color, modifier: Modifier) {
    Box(
        modifier.size(320.dp).blur(80.dp, BlurredEdgeTreatment.Unbounded)
            .padding(30.dp).background(color, CircleShape)
    )
}

@Composable
fun WatchersApp() {
    val p = if (isSystemInDarkTheme()) DarkPal else LightPal
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("watchers", 0) }
    val wish = remember { Saved(prefs, "wish") }
    val box = remember { Saved(prefs, "box") }
    var digital by remember { mutableStateOf(prefs.getBoolean("digital", false)) }
    var logoDigital by remember { mutableStateOf(prefs.getBoolean("logoDigital", false)) }
    var screen by remember { mutableStateOf(Screen.Catalog) }
    var menuOpen by remember { mutableStateOf(false) }
    var cat by remember { mutableStateOf("All") }
    var query by remember { mutableStateOf("") }
    val now = rememberNow()

    val flipLogo = {
        logoDigital = !logoDigital
        prefs.edit().putBoolean("logoDigital", logoDigital).apply()
    }
    val flipClock = {
        digital = !digital
        prefs.edit().putBoolean("digital", digital).apply()
    }

    Box(Modifier.fillMaxSize().background(p.bg)) {
        Blob(p.blob1, Modifier.align(Alignment.TopStart).offset((-110).dp, 60.dp))
        Blob(p.blob2, Modifier.align(Alignment.CenterEnd).offset(110.dp, 140.dp))
        Box(Modifier.fillMaxSize().blur(if (menuOpen) 24.dp else 0.dp)) {
            when (screen) {
                Screen.Catalog -> Frame(p, logoDigital, flipLogo) {
                    Section(p, ALL.filter { cat == "All" || it.cat == cat }, wish, box, true)
                }
                Screen.Trending -> Frame(p, logoDigital, flipLogo) {
                    Section(p, ALL.filter { it.trend }, wish, box, true)
                }
                Screen.Feed -> Frame(p, logoDigital, flipLogo) {
                    Column(Modifier.fillMaxWidth().bubble(p, RoundedCornerShape(28.dp)).padding(24.dp)) {
                        Text("Feed", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Posts from other collectors arrive in a later build. View only: no likes, comments or DMs.",
                            color = p.muted, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
                Screen.Watches -> Frame(p, logoDigital, flipLogo) {
                    Text("WISHLIST", color = p.acc, fontSize = 12.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Medium)
                    Section(p, ALL.filter { wish.has(it.name) }, wish, box, false)
                    Text("WATCH BOX", color = p.acc, fontSize = 12.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Medium)
                    Section(p, ALL.filter { box.has(it.name) }, wish, box, false)
                }
                Screen.Search -> Frame(p, logoDigital, flipLogo) {
                    Section(
                        p,
                        ALL.filter { it.name.contains(query, true) || it.cat.contains(query, true) },
                        wish, box, false
                    )
                }
            }
        }
        if (!menuOpen) {
            BottomBar(p, screen, cat, { cat = it }, query, { query = it }, now, digital, { menuOpen = true }, flipClock)
        }
        AnimatedVisibility(
            visible = menuOpen,
            enter = fadeIn() + scaleIn(initialScale = 0.85f, transformOrigin = TransformOrigin(0.5f, 1f)),
            exit = fadeOut() + scaleOut(targetScale = 0.85f, transformOrigin = TransformOrigin(0.5f, 1f))
        ) {
            RadialMenu(p, now, screen, { screen = it; menuOpen = false }, { menuOpen = false })
        }
    }
}
